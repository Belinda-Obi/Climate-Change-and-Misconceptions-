# People underestimate others' willingness to take climate action - Data package

This data package contains the data that powers the chart ["People underestimate others' willingness to take climate action"](https://ourworldindata.org/grapher/willingness-climate-action?v=1&csvType=full&useColumnShortNames=false) on the Our World in Data website.

## CSV Structure

The high level structure of the CSV file is that each row is an observation for an entity (usually a country or region) and a timepoint (usually a year).

The first two columns in the CSV file are "Entity" and "Code". "Entity" is the name of the entity (e.g. "United States"). "Code" is the OWID internal entity code that we use if the entity is a country or region. For most countries, this is the same as the [iso alpha-3](https://en.wikipedia.org/wiki/ISO_3166-1_alpha-3) code of the entity (e.g. "USA") - for non-standard countries like historical countries these are custom codes.

The third column is either "Year" or "Day". If the data is annual, this is "Year" and contains only the year as an integer. If the column is "Day", the column contains a date string in the form "YYYY-MM-DD".

The remaining columns are the data columns, each of which is a time series. If the CSV data is downloaded using the "full data" option, then each column corresponds to one time series below. If the CSV data is downloaded using the "only selected data visible in the chart" option then the data columns are transformed depending on the chart type and thus the association with the time series might not be as straightforward.


## Metadata.json structure

The .metadata.json file contains metadata about the data package. The "charts" key contains information to recreate the chart, like the title, subtitle etc.. The "columns" key contains information about each of the columns in the csv, like the unit, timespan covered, citation for the data etc..

## About the data

Our World in Data is almost never the original producer of the data - almost all of the data we use has been compiled by others. If you want to re-use data, it is your responsibility to ensure that you adhere to the sources' license and to credit them correctly. Please note that a single time series may have more than one source - e.g. when we stich together data from different time periods by different producers or when we calculate per capita metrics using population data from a second source.

### How we process data at Our World In Data
All data and visualizations on Our World in Data rely on data sourced from one or several original data providers. Preparing this original data involves several processing steps. Depending on the data, this can include standardizing country names and world region definitions, converting units, calculating derived indicators such as per capita measures, as well as adding or adapting metadata such as the name or the description given to an indicator.
[Read about our data pipeline](https://docs.owid.io/projects/etl/)

## Detailed information about each time series


## Predicted share willing to give
The share of the population in their country that people think would be willing to give 1% of their income to tackle climate change.
Last updated: February 18, 2024  
Date range: 2024–2024  
Unit: %  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
Andre et al. (2024). Globally representative evidence on the actual and perceived support for climate action. – processed by Our World in Data

#### Full citation
Andre et al. (2024). Globally representative evidence on the actual and perceived support for climate action. – processed by Our World in Data. “Predicted share willing to give” [dataset]. Andre et al. (2024). Globally representative evidence on the actual and perceived support for climate action., “public_support_climate_andre” [original data].
Source: Andre et al. (2024). Globally representative evidence on the actual and perceived support for climate action. – processed by Our World In Data

### What you should know about this data

### Source

#### Andre et al. (2024). Globally representative evidence on the actual and perceived support for climate action. – public_support_climate_andre
Retrieved on: 2024-02-18  
Retrieved from: https://www.nature.com/articles/s41558-024-01925-3  


## Actual share who said they were willing to give 1% of their income
Share that say they would be willing to give 1% of their income to tackle climate change.
Last updated: February 18, 2024  
Date range: 2024–2024  
Unit: %  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
Andre et al. (2024). Globally representative evidence on the actual and perceived support for climate action. – processed by Our World in Data

#### Full citation
Andre et al. (2024). Globally representative evidence on the actual and perceived support for climate action. – processed by Our World in Data. “Actual share who said they were willing to give 1% of their income” [dataset]. Andre et al. (2024). Globally representative evidence on the actual and perceived support for climate action., “public_support_climate_andre” [original data].
Source: Andre et al. (2024). Globally representative evidence on the actual and perceived support for climate action. – processed by Our World In Data

### What you should know about this data

### Source

#### Andre et al. (2024). Globally representative evidence on the actual and perceived support for climate action. – public_support_climate_andre
Retrieved on: 2024-02-18  
Retrieved from: https://www.nature.com/articles/s41558-024-01925-3  


## World region according to OWID
Regions defined by Our World in Data, which are used in OWID charts and maps.
Last updated: January 1, 2023  
Date range: 2023–2023  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
Our World in Data – processed by Our World in Data

#### Full citation
Our World in Data – processed by Our World in Data. “World region according to OWID” [dataset]. Our World in Data, “Regions” [original data].
Source: Our World in Data

### Source

#### Our World in Data – Regions


    